﻿using RimWorld;

namespace SRTS;

[DefOf]
public static class StaticDefOf
{
    public static WorldObjectDef TravelingSRTS_Carryall;
}